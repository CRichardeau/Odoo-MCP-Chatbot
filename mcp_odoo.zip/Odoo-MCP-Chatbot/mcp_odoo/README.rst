.. image:: https://img.shields.io/badge/license-LGPL--3-blue.svg
    :target: https://www.gnu.org/licenses/lgpl-3.0-standalone.html
    :alt: License: LGPL-3

Chatbot MCP Odoo
================
* Chatbot MCP Odoo

Configuration
=============
- Additional configuration not required

License
-------
Lesser General Public License, Version 3 (LGPL v3).
(https://www.gnu.org/licenses/agpl-3.0-standalone.html)

Company
-------
* `CHEF PIXEL <https://chef-pixel.fr/>`__

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
This module is maintained by CHEF PIXEL

For support and more information, please visit `Our Website <https://chef-pixel.fr/>`__

Further information
===================
HTML Description: `<static/description/index.html>`__
